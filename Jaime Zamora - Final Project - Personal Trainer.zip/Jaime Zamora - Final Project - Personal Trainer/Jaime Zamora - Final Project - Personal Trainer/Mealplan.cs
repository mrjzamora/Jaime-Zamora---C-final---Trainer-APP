﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jaime_Zamora___Final_Project___Personal_Trainer
{
    public class Mealplan
    {
        public Mealplan(string type, int cost)
        {
            MealPlanType = type;
            MealPlanCost = cost;
        }

        public string MealPlanType { get; set; }
        public int MealPlanCost { get; set; }
        public static int ChosenMealIndex { get; set; }

        public override string ToString()
        {
            return String.Format("Meal Type: {0}" + Environment.NewLine +
                                 "Meal Cost: {1:C}" + Environment.NewLine,
                                  MealPlanType, MealPlanCost);
        }
    }
}
