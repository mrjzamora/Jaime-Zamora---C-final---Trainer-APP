﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Jaime_Zamora___Final_Project___Personal_Trainer
{
    public partial class TotalCharges : Form
    {
        public TotalCharges()
        {
            InitializeComponent();
            Display();
        }

        private void ReturnBotton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Display()
        {
            OutPutBoxMultiline.Text += MainForm1.gyms[Gyms.ChosenGymIndex].ToString();
            OutPutBoxMultiline.Text += MainForm1.meals[Mealplan.ChosenMealIndex].ToString();
            OutPutBoxMultiline.Text += "total Cost" + Calctotal().ToString("C");
        }

        private int Calctotal()
        {
            int gymcost = MainForm1.gyms[Gyms.ChosenGymIndex].GymCost;
            int mealcost = MainForm1.meals[Mealplan.ChosenMealIndex].MealPlanCost;
            return gymcost + mealcost;
        }

        private void OutPutBoxMultiline_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
