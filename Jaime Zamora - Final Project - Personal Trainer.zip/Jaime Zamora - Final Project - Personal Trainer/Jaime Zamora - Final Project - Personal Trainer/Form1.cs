﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Jaime_Zamora___Final_Project___Personal_Trainer
{
    public partial class MainForm1 : Form
    {
        public MainForm1()
        {
            InitializeComponent();
            Initialize();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        public static List<Gyms> gyms = new List<Gyms>();
        public static List<Mealplan> meals = new List<Mealplan>();
        private void btnCalculate_Click_Click(object sender, EventArgs e)
        {
            TotalCharges form2 = new TotalCharges();
            Gyms.ChosenGymIndex = DropDownLocationBox.SelectedIndex;

            if (radioButton1.Checked)
                Mealplan.ChosenMealIndex = 0;
            else if (radioButton2.Checked)
                Mealplan.ChosenMealIndex = 1;
            else
                Mealplan.ChosenMealIndex = 2;

            form2.ShowDialog();

        }

        private void Initialize()
        {
            try
            {
                PopulateGym();
                PopulateMeals();
                PopulateDropDown();


            }
            catch (Exception ex) 
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void PopulateDropDown()
        {
            DropDownLocationBox.Text = "Select Location";
            foreach(Gyms d in gyms) 
            {
                DropDownLocationBox.Items.Add(d.GymType);
            }
        }
        private void PopulateGym()
        {
            StreamReader sr = new StreamReader("Locations.txt");
            while (!sr.EndOfStream) 
            {
                string[] data = sr.ReadLine().Split(',');
                gyms.Add(new Gyms(data[0], Convert.ToInt32(data[1])));

            }

            sr.Close();

        }

        private void PopulateMeals() 
        {
            StreamReader sr = new StreamReader("MealPlans.txt");
            while (!sr.EndOfStream)
            {
                string[] data = sr.ReadLine().Split(',');
                meals.Add(new Mealplan(data[0], Convert.ToInt32(data[1])));

            }

            sr.Close();
        }

        private void DropDownLocationBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
