﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jaime_Zamora___Final_Project___Personal_Trainer
{
    public class Gyms

    {        
      public Gyms(string type, int cost)
        { 

            GymType = type;
            GymCost = cost;
        }

      public string GymType { get; set; }
      public int GymCost { get; set; }
      public static int ChosenGymIndex {  get; set; }

        public override string ToString()
        {
            return String.Format("Gym type: {0}" + Environment.NewLine +
                                 "Gym Cost: {1:C}" + Environment.NewLine, GymType, GymCost);
                          
        }

    }
}
