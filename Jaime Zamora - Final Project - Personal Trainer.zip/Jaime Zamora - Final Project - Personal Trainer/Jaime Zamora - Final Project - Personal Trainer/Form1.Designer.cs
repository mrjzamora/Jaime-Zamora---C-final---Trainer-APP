﻿namespace Jaime_Zamora___Final_Project___Personal_Trainer
{
    partial class MainForm1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm1));
            this.DropDownLocationBox = new System.Windows.Forms.ListBox();
            this.labelSelectLocation = new System.Windows.Forms.Label();
            this.labelHealthyEatingPlan = new System.Windows.Forms.Label();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.btnCalculate_Click = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // DropDownLocationBox
            // 
            this.DropDownLocationBox.AllowDrop = true;
            this.DropDownLocationBox.BackColor = System.Drawing.Color.Black;
            this.DropDownLocationBox.Font = new System.Drawing.Font("Segoe Print", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DropDownLocationBox.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.DropDownLocationBox.FormattingEnabled = true;
            this.DropDownLocationBox.ItemHeight = 26;
            this.DropDownLocationBox.Location = new System.Drawing.Point(53, 110);
            this.DropDownLocationBox.Name = "DropDownLocationBox";
            this.DropDownLocationBox.ScrollAlwaysVisible = true;
            this.DropDownLocationBox.Size = new System.Drawing.Size(208, 108);
            this.DropDownLocationBox.TabIndex = 0;
            this.DropDownLocationBox.SelectedIndexChanged += new System.EventHandler(this.DropDownLocationBox_SelectedIndexChanged);
            // 
            // labelSelectLocation
            // 
            this.labelSelectLocation.AutoSize = true;
            this.labelSelectLocation.BackColor = System.Drawing.Color.Transparent;
            this.labelSelectLocation.Font = new System.Drawing.Font("Segoe UI Black", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSelectLocation.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.labelSelectLocation.Location = new System.Drawing.Point(54, 86);
            this.labelSelectLocation.Name = "labelSelectLocation";
            this.labelSelectLocation.Size = new System.Drawing.Size(119, 20);
            this.labelSelectLocation.TabIndex = 1;
            this.labelSelectLocation.Text = "Select Location";
            // 
            // labelHealthyEatingPlan
            // 
            this.labelHealthyEatingPlan.AutoSize = true;
            this.labelHealthyEatingPlan.BackColor = System.Drawing.Color.Transparent;
            this.labelHealthyEatingPlan.Font = new System.Drawing.Font("Segoe UI Black", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelHealthyEatingPlan.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelHealthyEatingPlan.Location = new System.Drawing.Point(53, 248);
            this.labelHealthyEatingPlan.Name = "labelHealthyEatingPlan";
            this.labelHealthyEatingPlan.Size = new System.Drawing.Size(152, 20);
            this.labelHealthyEatingPlan.TabIndex = 2;
            this.labelHealthyEatingPlan.Text = "Healthy Eating Plan";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.ForeColor = System.Drawing.Color.Coral;
            this.radioButton1.Location = new System.Drawing.Point(58, 285);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(183, 20);
            this.radioButton1.TabIndex = 3;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "7 Meals Per Week ( $600 )";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.ForeColor = System.Drawing.Color.Coral;
            this.radioButton2.Location = new System.Drawing.Point(58, 324);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(197, 20);
            this.radioButton2.TabIndex = 4;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "14 Meals Per Week ($1,200 )";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.ForeColor = System.Drawing.Color.Coral;
            this.radioButton3.Location = new System.Drawing.Point(58, 366);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(139, 20);
            this.radioButton3.TabIndex = 5;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "Unlimited ( $1,700 )";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // btnCalculate_Click
            // 
            this.btnCalculate_Click.Location = new System.Drawing.Point(58, 441);
            this.btnCalculate_Click.Name = "btnCalculate_Click";
            this.btnCalculate_Click.Size = new System.Drawing.Size(92, 23);
            this.btnCalculate_Click.TabIndex = 6;
            this.btnCalculate_Click.Text = "Calculate";
            this.btnCalculate_Click.UseVisualStyleBackColor = true;
            this.btnCalculate_Click.Click += new System.EventHandler(this.btnCalculate_Click_Click);
            // 
            // MainForm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BackgroundImage = global::Jaime_Zamora___Final_Project___Personal_Trainer.Properties.Resources.wall_paper;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(909, 506);
            this.Controls.Add(this.btnCalculate_Click);
            this.Controls.Add(this.radioButton3);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.labelHealthyEatingPlan);
            this.Controls.Add(this.labelSelectLocation);
            this.Controls.Add(this.DropDownLocationBox);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm1";
            this.Text = "Jaime Zamora - Personal Trainer";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox DropDownLocationBox;
        private System.Windows.Forms.Label labelSelectLocation;
        private System.Windows.Forms.Label labelHealthyEatingPlan;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.Button btnCalculate_Click;
    }
}

