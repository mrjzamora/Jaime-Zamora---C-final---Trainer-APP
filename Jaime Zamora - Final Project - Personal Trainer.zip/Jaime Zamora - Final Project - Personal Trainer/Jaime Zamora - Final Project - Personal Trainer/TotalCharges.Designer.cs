﻿namespace Jaime_Zamora___Final_Project___Personal_Trainer
{
    partial class TotalCharges
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TotalCharges));
            this.OutPutBoxMultiline = new System.Windows.Forms.TextBox();
            this.ReturnBotton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // OutPutBoxMultiline
            // 
            this.OutPutBoxMultiline.BackColor = System.Drawing.Color.Silver;
            this.OutPutBoxMultiline.Font = new System.Drawing.Font("Perpetua Titling MT", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OutPutBoxMultiline.Location = new System.Drawing.Point(12, 37);
            this.OutPutBoxMultiline.Multiline = true;
            this.OutPutBoxMultiline.Name = "OutPutBoxMultiline";
            this.OutPutBoxMultiline.Size = new System.Drawing.Size(348, 205);
            this.OutPutBoxMultiline.TabIndex = 0;
            this.OutPutBoxMultiline.TextChanged += new System.EventHandler(this.OutPutBoxMultiline_TextChanged);
            // 
            // ReturnBotton
            // 
            this.ReturnBotton.Font = new System.Drawing.Font("Segoe UI Historic", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ReturnBotton.Location = new System.Drawing.Point(79, 276);
            this.ReturnBotton.Name = "ReturnBotton";
            this.ReturnBotton.Size = new System.Drawing.Size(163, 53);
            this.ReturnBotton.TabIndex = 1;
            this.ReturnBotton.Text = "Return To Main Form";
            this.ReturnBotton.UseVisualStyleBackColor = true;
            this.ReturnBotton.Click += new System.EventHandler(this.ReturnBotton_Click);
            // 
            // TotalCharges
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BackgroundImage = global::Jaime_Zamora___Final_Project___Personal_Trainer.Properties.Resources.gym_guy;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.ReturnBotton);
            this.Controls.Add(this.OutPutBoxMultiline);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "TotalCharges";
            this.Text = "Total Charges";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox OutPutBoxMultiline;
        private System.Windows.Forms.Button ReturnBotton;
    }
}